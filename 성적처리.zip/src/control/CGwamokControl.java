package control;

import entity.CGwamok;

public class CGwamokControl {

	public CGwamok processGwamok(CGwamok gwamok) {
		// TODO Auto-generated method stub
		return gwamok;
	}

}
