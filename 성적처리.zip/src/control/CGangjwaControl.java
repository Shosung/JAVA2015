package control;

import entity.CGangjwa;

public class CGangjwaControl {

	public CGangjwa processGangjwa(CGangjwa gangjwa) {
		// TODO Auto-generated method stub
		return gangjwa;
	}

}
